const Game = require('../models/gameModel');

// Controller to create a game
const createGame = async (req, res) => {
  const { title, original_price, game_description, reviews } = req.body;

  try {
    // Validate required fields
    if (!title || original_price === undefined) {
      return res.status(400).json({ message: 'Title and Original Price are required.' });
    }

    const newGame = new Game({
      title: title.trim(),
      original_price: parseFloat(original_price),
      game_description: game_description?.trim() || 'No description available',
      reviews: Array.isArray(reviews) ? reviews.filter((r) => r.trim()) : [],
    });

    const savedGame = await newGame.save();
    res.status(201).json(savedGame);
  } catch (error) {
    res.status(500).json({ error: `Failed to create game: ${error.message}` });
  }
};

// Controller to fetch all games with pagination
const getAllGames = async (req, res) => {
  const { page = 1, limit = 10, title = '' } = req.query; // Added title for optional filtering
  const skip = (page - 1) * limit;

  try {
    const query = title ? { title: new RegExp(title, 'i') } : {}; // Case-insensitive title search

    const games = await Game.find(query)
      .skip(skip)
      .limit(Number(limit))
      .select('title original_price game_description reviews'); // Only return specified fields

    const totalGames = await Game.countDocuments(query); // Total number of filtered documents
    const totalPages = Math.ceil(totalGames / limit);

    res.status(200).json({ games, totalPages });
  } catch (error) {
    res.status(500).json({ error: `Failed to fetch games: ${error.message}` });
  }
};

// Controller to update a game
const updateGame = async (req, res) => {
  const { id } = req.params;
  const { title, original_price, game_description, reviews } = req.body;

  try {
    // Update only provided fields
    const updateFields = {};
    if (title) updateFields.title = title.trim();
    if (original_price !== undefined) updateFields.original_price = parseFloat(original_price);
    if (game_description) updateFields.game_description = game_description.trim();
    if (Array.isArray(reviews)) updateFields.reviews = reviews.filter((r) => r.trim());

    const updatedGame = await Game.findByIdAndUpdate(id, updateFields, {
      new: true,
      runValidators: true, // Ensure validation rules are applied
    });

    if (!updatedGame) {
      return res.status(404).json({ message: 'Game not found' });
    }

    res.status(200).json(updatedGame);
  } catch (error) {
    res.status(400).json({ error: `Failed to update game: ${error.message}` });
  }
};

// Controller to delete a game
const deleteGame = async (req, res) => {
  const { id } = req.params;

  try {
    const deletedGame = await Game.findByIdAndDelete(id);

    if (!deletedGame) {
      return res.status(404).json({ message: 'Game not found' });
    }

    res.status(200).json({ message: 'Game deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: `Failed to delete game: ${error.message}` });
  }
};

module.exports = { createGame, getAllGames, updateGame, deleteGame };
