const mongoose = require('mongoose');

const gameSchema = new mongoose.Schema({
  title: { type: String, required: true },
  originalPrice: { type: String, default: "Free" },
  discountedPrice: { type: String, default: "Free" },
  releaseDate: { type: String, required: true },
  link: { type: String },
  description: { type: String, default: "No description available" },
  recentReviewsSummary: { type: String, default: "No reviews available" },
  allReviewsSummary: { type: String, default: "No reviews available" },
  recentReviewsNumber: { type: String, default: "No recent reviews available" },
  allReviewsNumber: { type: String, default: "No reviews available" },
  developer: { type: [String], default: [] },
  publisher: { type: String },
  supportedLanguages: { type: [String], default: [] },
  popularTags: { type: [String], default: [] },
  gameFeatures: { type: [String], default: [] },
  minimumRequirements: { type: String },
});

const Game = mongoose.model('Game', gameSchema, 'game_library'); // Explicitly specify collection name

module.exports = Game;
