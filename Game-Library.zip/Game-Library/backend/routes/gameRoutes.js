const express = require('express');
const Game = require('../models/gameModel'); // Import Game model

const router = express.Router();

// Route to fetch all games with pagination and optional title filter
router.get('/', async (req, res) => {
  const { title = '', page = 1, limit = 10 } = req.query;
  const skip = (page - 1) * limit;

  try {
    // Apply title filter if provided
    const query = title ? { title: { $regex: title, $options: 'i' } } : {}; // Case-insensitive regex filter
    const games = await Game.find(query).skip(skip).limit(Number(limit));
    const totalGames = await Game.countDocuments(query);

    // Add fallback values for empty fields
    const formattedGames = games.map((game) => ({
      ...game._doc,
      supportedLanguages: game.supportedLanguages.length ? game.supportedLanguages : ["Unknown"],
      popularTags: game.popularTags.length ? game.popularTags : ["No Tags Available"],
      gameFeatures: game.gameFeatures.length ? game.gameFeatures : ["No Features Available"]
    }));

    const totalPages = Math.ceil(totalGames / limit);
    res.status(200).json({ games: formattedGames, totalPages });
  } catch (error) {
    console.error('Error fetching games:', error);
    res.status(500).json({ error: error.message });
  }
});

// Route to fetch a single game by ID
router.get('/:id', async (req, res) => {
  try {
    const game = await Game.findById(req.params.id);
    if (!game) {
      return res.status(404).json({ error: 'Game not found' });
    }
    res.status(200).json(game);
  } catch (error) {
    console.error('Error fetching game:', error);
    res.status(500).json({ error: error.message });
  }
});

// Route to create a new game
router.post('/', async (req, res) => {
  try {
    const game = new Game(req.body);
    const savedGame = await game.save();
    res.status(201).json(savedGame);
  } catch (error) {
    console.error('Error creating game:', error);
    res.status(500).json({ error: error.message });
  }
});

// Route to update a game by ID
router.put('/:id', async (req, res) => {
  try {
    const updatedGame = await Game.findByIdAndUpdate(req.params.id, req.body, { new: true });
    if (!updatedGame) {
      return res.status(404).json({ error: 'Game not found' });
    }
    res.status(200).json(updatedGame);
  } catch (error) {
    console.error('Error updating game:', error);
    res.status(500).json({ error: error.message });
  }
});

// Route to delete a game by ID
router.delete('/:id', async (req, res) => {
  try {
    const deletedGame = await Game.findByIdAndDelete(req.params.id);
    if (!deletedGame) {
      return res.status(404).json({ error: 'Game not found' });
    }
    res.status(200).json({ message: 'Game deleted successfully' });
  } catch (error) {
    console.error('Error deleting game:', error);
    res.status(500).json({ error: error.message });
  }
});

// Route to count all games
router.get('/count', async (req, res) => {
  try {
    const count = await Game.countDocuments();
    res.status(200).json({ count });
  } catch (error) {
    console.error('Error counting games:', error);
    res.status(500).json({ error: error.message });
  }
});

module.exports = router;
