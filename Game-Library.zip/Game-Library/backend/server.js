const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const path = require('path');
require('dotenv').config(); // Load environment variables from .env file

const gameRoutes = require('./routes/gameRoutes'); // Import game routes

const app = express();
const PORT = process.env.PORT || 5000; // Set the port

// Middleware
app.use(cors()); // Enable Cross-Origin Resource Sharing
app.use(express.json()); // Parse JSON bodies

// API Routes
app.use('/api/games', gameRoutes); // Mount game routes

// Serve static files from the frontend
app.use(express.static(path.join(__dirname, '../frontend/public')));

// Serve index.html for unknown routes
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, '../frontend/public/index.html'));
});

// Connect to MongoDB and Start the Server
mongoose
  .connect(process.env.MONGO_URI, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(() => {
    console.log('Connected to MongoDB');
    app.listen(PORT, () => console.log(`Server running on http://localhost:${PORT}`));
  })
  .catch((error) => {
    console.error('MongoDB connection error:', error);
  });
