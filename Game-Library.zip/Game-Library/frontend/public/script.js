const API_URL = 'http://localhost:5000/api/games'; // Backend API URL

// State to manage pagination
let currentPage = 1;
const gamesPerPage = 10;

// Function to fetch and display all games with grid layout and pagination
const fetchGames = async (page = 1) => {
  try {
    const response = await fetch(`${API_URL}?page=${page}&limit=${gamesPerPage}`);
    if (!response.ok) throw new Error('Failed to fetch games');
    const { games, totalPages } = await response.json();

    const gamesGrid = document.getElementById('games');
    gamesGrid.innerHTML = ''; // Clear the grid

    games.forEach((game) => {
      const gameCard = document.createElement('div');
      gameCard.className = 'game-card';
      gameCard.innerHTML = `
        <h3>${game.title}</h3>
        <p><strong>Price:</strong> ${game.originalPrice}</p>
        <p><strong>Release Date:</strong> ${game.releaseDate}</p>
        <p><strong>Publisher:</strong> ${game.publisher || 'Unknown'}</p>
        <button onclick="viewDetails('${game._id}')">View Details</button>
        <button onclick="updateGame('${game._id}')">Update</button>
        <button onclick="deleteGame('${game._id}')">Delete</button>
      `;
      gamesGrid.appendChild(gameCard);
    });

    updatePagination(totalPages, page, fetchGames, 'pagination');
  } catch (error) {
    console.error('Error fetching games:', error);
  }
};

// Function to fetch and display game details in a modal
const viewDetails = async (id) => {
  try {
    const response = await fetch(`${API_URL}/${id}`);
    if (!response.ok) throw new Error('Failed to fetch game details');
    const game = await response.json();

    // Display game details in a modal
    const modal = document.getElementById('game-modal');
    modal.innerHTML = `
      <h2>${game.title}</h2>
      <p><strong>Price:</strong> ${game.originalPrice}</p>
      <p><strong>Description:</strong> ${game.description}</p>
      <p><strong>Release Date:</strong> ${game.releaseDate}</p>
      <p><strong>Publisher:</strong> ${game.publisher}</p>
      <p><strong>Languages:</strong> ${game.supportedLanguages.length ? game.supportedLanguages.join(', ') : 'Unknown'}</p>
      <button onclick="closeModal()">Close</button>
    `;
    modal.style.display = 'block';
  } catch (error) {
    console.error('Error fetching game details:', error);
  }
};

// Function to update a game
const updateGame = async (id) => {
  const newTitle = prompt('Enter new title for the game:');
  const newPrice = prompt('Enter new price for the game:');
  const newDescription = prompt('Enter new description for the game:');

  if (newTitle && newPrice && newDescription) {
    try {
      const response = await fetch(`${API_URL}/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          title: newTitle,
          originalPrice: newPrice,
          description: newDescription,
        }),
      });

      if (!response.ok) throw new Error('Failed to update game');
      alert('Game updated successfully!');
      fetchGames(currentPage); // Refresh the games list
    } catch (error) {
      console.error('Error updating game:', error);
    }
  } else {
    alert('All fields are required for the update.');
  }
};

// Function to delete a game
const deleteGame = async (id) => {
  const confirmDelete = confirm('Are you sure you want to delete this game?');
  if (confirmDelete) {
    try {
      const response = await fetch(`${API_URL}/${id}`, {
        method: 'DELETE',
      });

      if (!response.ok) throw new Error('Failed to delete game');
      alert('Game deleted successfully!');
      fetchGames(currentPage); // Refresh the games list
    } catch (error) {
      console.error('Error deleting game:', error);
    }
  }
};

// Function to close the modal
const closeModal = () => {
  const modal = document.getElementById('game-modal');
  modal.style.display = 'none';
};

// Pagination logic with range
const updatePagination = (totalPages, currentPage, fetchFunction, containerId) => {
  const paginationContainer = document.getElementById(containerId);
  if (!paginationContainer) {
    console.error(`Error: '${containerId}' element not found.`);
    return;
  }

  paginationContainer.innerHTML = ''; // Clear pagination
  const maxVisiblePages = 5; // Limit the number of visible page buttons

  const createButton = (text, isDisabled, onClick) => {
    const button = document.createElement('button');
    button.innerText = text;
    button.disabled = isDisabled;
    button.onclick = onClick;
    return button;
  };

  const prevButton = createButton('«', currentPage === 1, () => fetchFunction(currentPage - 1));
  paginationContainer.appendChild(prevButton);

  const startPage = Math.max(1, currentPage - Math.floor(maxVisiblePages / 2));
  const endPage = Math.min(totalPages, startPage + maxVisiblePages - 1);

  for (let i = startPage; i <= endPage; i++) {
    const pageButton = createButton(i, i === currentPage, () => fetchFunction(i));
    paginationContainer.appendChild(pageButton);
  }

  const nextButton = createButton('»', currentPage === totalPages, () => fetchFunction(currentPage + 1));
  paginationContainer.appendChild(nextButton);
};

// Attach functionality to "View More Games" button
document.getElementById('view-catalogue-btn')?.addEventListener('click', () => {
  currentPage = 1;
  fetchGames(currentPage);
});

// Attach Search Form Logic
document.getElementById('search-form')?.addEventListener('submit', (e) => {
  e.preventDefault();
  const title = document.getElementById('search-input').value.trim();
  if (title) {
    searchGames(title);
  } else {
    fetchGames(); // Fallback to fetch all games
  }
});

// Search Function
const searchGames = async (title, page = 1) => {
  try {
    const response = await fetch(`${API_URL}?title=${encodeURIComponent(title)}&page=${page}&limit=${gamesPerPage}`);
    if (!response.ok) throw new Error('Error searching games');
    const { games, totalPages } = await response.json();

    const gamesGrid = document.getElementById('games');
    gamesGrid.innerHTML = ''; // Clear the grid

    games.forEach((game) => {
      const gameCard = document.createElement('div');
      gameCard.className = 'game-card';
      gameCard.innerHTML = `
        <h3>${game.title}</h3>
        <p><strong>Price:</strong> ${game.originalPrice}</p>
        <p><strong>Release Date:</strong> ${game.releaseDate}</p>
        <p><strong>Publisher:</strong> ${game.publisher || 'Unknown'}</p>
        <button onclick="viewDetails('${game._id}')">View Details</button>
        <button onclick="updateGame('${game._id}')">Update</button>
        <button onclick="deleteGame('${game._id}')">Delete</button>
      `;
      gamesGrid.appendChild(gameCard);
    });

    updatePagination(totalPages, page, (p) => searchGames(title, p), 'pagination');
  } catch (error) {
    console.error('Error searching games:', error);
  }
};

// Fetch games on page load
fetchGames();
