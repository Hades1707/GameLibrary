import React, { useState, useEffect } from 'react';

const App = () => {
  const [games, setGames] = useState([]);
  const API_URL = 'http://localhost:5000/api/games';

  // Fetch games from the backend
  const fetchGames = async () => {
    try {
      const response = await fetch(API_URL);
      const data = await response.json();
      setGames(data);
    } catch (error) {
      console.error('Error fetching games:', error);
    }
  };

  useEffect(() => {
    fetchGames();
  }, []);

  return (
    <div>
      <header>
        <h1>Game Library</h1>
      </header>
      <main>
        <section>
          <h2>All Games</h2>
          <ul>
            {games.map((game) => (
              <li key={game._id}>
                <strong>{game.title}</strong> - ${game.original_price}
                <p>{game.reviews?.join(', ') || 'No reviews yet'}</p>
              </li>
            ))}
          </ul>
        </section>
      </main>
    </div>
  );
};

export default App;
