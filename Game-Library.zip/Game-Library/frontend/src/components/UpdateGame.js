import React, { useState } from 'react';
import axios from 'axios';

const UpdateGame = ({ id }) => {
  const [price, setPrice] = useState('');

  const handleSubmit = async (e) => {
    e.preventDefault();
    await axios.put(`/api/games/${id}`, { original_price: price });
    window.location.reload();
  };

  return (
    <form onSubmit={handleSubmit}>
      <input type="number" placeholder="New Price" value={price} onChange={(e) => setPrice(e.target.value)} />
      <button type="submit">Update Price</button>
    </form>
  );
};

export default UpdateGame;
