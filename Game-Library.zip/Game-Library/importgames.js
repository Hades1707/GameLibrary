const { MongoClient } = require('mongodb');

async function transformFields() {
  const uri = 'your_mongodb_connection_string'; // Replace with your connection string
  const client = new MongoClient(uri);

  try {
    await client.connect();
    const database = client.db('games'); // Replace with your database name
    const collection = database.collection('game_library'); // Replace with your collection name

    // Fetch all documents from the collection
    const cursor = collection.find({});
    const updates = [];

    await cursor.forEach((doc) => {
      const updatedDoc = {};

      // Transform gameFeatures
      if (typeof doc.gameFeatures === 'string') {
        try {
          updatedDoc.gameFeatures = JSON.parse(doc.gameFeatures);
        } catch {
          updatedDoc.gameFeatures = [];
        }
      }

      // Transform popularTags
      if (typeof doc.popularTags === 'string') {
        try {
          updatedDoc.popularTags = JSON.parse(doc.popularTags);
        } catch {
          updatedDoc.popularTags = [];
        }
      }

      // Transform supportedLanguages
      if (typeof doc.supportedLanguages === 'string') {
        try {
          updatedDoc.supportedLanguages = JSON.parse(doc.supportedLanguages);
        } catch {
          updatedDoc.supportedLanguages = [];
        }
      }

      if (Object.keys(updatedDoc).length > 0) {
        updates.push({
          updateOne: {
            filter: { _id: doc._id },
            update: { $set: updatedDoc }
          }
        });
      }
    });

    // Perform bulk updates
    if (updates.length > 0) {
      const result = await collection.bulkWrite(updates);
      console.log(`${result.modifiedCount} documents updated.`);
    } else {
      console.log('No documents needed updates.');
    }
  } catch (err) {
    console.error('Error:', err);
  } finally {
    await client.close();
  }
}

transformFields();
